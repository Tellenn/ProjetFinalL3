# ProjetFinalL

[La TODO LIST](https://github.com/Tellenn/ProjetFinalL3#todo-list-) 

[La liste des choses à faire pendant les vacances](https://github.com/Tellenn/ProjetFinalL3#holiday-work-)


# Holiday work : 

- RMI : 
	- ~~Chat à au moins deux utilisateurs~~ _Fait par Carine et Antoine_
	- ~~Envoi de fichier~~ _Kyllian_
- Base de donnée :
	- ~~Lister les requètes de consultation et modification des bases~~ _Kyllian_
- XML : 
	- ~~Faire un parser qui parcours les trois documents qui existent~~ _Ibrahima_
- Specs : 
	- ~~Faire les specs pour chaque fonction qui existe dans des fichiers~~
		- ~~Calendrier~~ _Quentin_
		- ~~GED : commencé~~ _Quentin_
		- ~~UserManagement~~ _Quentin_
		- ~~Chat~~ _Quentin_


# TODO LIST :

- Gestion de projet :
	- ~~Recherches sur RMI~~ _Carine_
	- ~~Cahier des Charges~~ _Antoine_
	- ~~Planning prévisionnel~~ _Quentin_
	- ~~Représentation des classes~~ _Kyllian a fait un travail nul_

- GED :
	- ~~BD~~ _Carine_
	- ~~XML~~ _Kyllian_
	- CLIENT _Ibrahima & Kyllian_
	- SERVEUR _Ibrahima & Kyllian_
	
	
- Gestion utilisateur :
	- ~~BD~~ _Ibrahima_
	- ~~XML~~ _Ibrahima_
	- ~~CLIENT~~ _Carine championne_
	- ~~SERVEUR~~ _Carine championne_
	
- Chat :
	- ~~BD~~ _Kyllian_
	- ~~XML~~ _Kyllian_
	- CLIENT _Antoine_
		- Salons
		- Messagerie privée
	- SERVEUR _Antoine_
		- Salons
		- Messagerie privée
	
- Calendrier :
	- ~~BD~~ _Quentin_
	- ~~XML~~ _Quentin_
	- CLIENT _Quentin_
	- SERVEUR
