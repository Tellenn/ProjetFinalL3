package chat;

public interface xmlDomParser {

}
