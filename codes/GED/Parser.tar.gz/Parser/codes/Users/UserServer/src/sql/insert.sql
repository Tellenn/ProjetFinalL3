INSERT INTO Utilisateur (idUser,userName,userPassword) VALUES (1,'charroan','toto123');
INSERT INTO Utilisateur (idUser,userName,userPassword) VALUES (2,'amina','toto123');
commit;