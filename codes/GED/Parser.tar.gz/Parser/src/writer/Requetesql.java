package writer;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author diallo1
 */
public class Requetesql {
public Requetesql(){}
 
     /* PARTIE SERVEUR */

/**
* Ajoute un document à la GED
* @param iddoc
* @param nomD
* @param nomDoc	
* @param iduser	
* @param typeDoc
* @param datedep
* @param chemin	
*/
public static void addDoc(int iddoc,String nomD,int iduser,String typeDoc, String datedep,String nomDoc,String chemin){
    String sql = "INSERT INTO Fichier VALUES (?,?,?,?,?)";
    try {
    Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
    conn.setAutoCommit(true);
    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
    pstmt.setInt(1, iddoc);
    pstmt.setString(2, nomDoc);
    pstmt.setInt(3, iduser);
    pstmt.setString(4, typeDoc);
    pstmt.setString(5, datedep);
    pstmt.executeUpdate();
    conn.commit();
    System.out.println("Fichier creer");
    }
    } catch (SQLException e) {System.err.println(e.getMessage());}
}
/**
* Ajoute un document à la GED
* @param nomDoc
* @param chemin	
*/
public static void addDocPhys(String nomDoc,String chemin){
  destinationFile=new File("C:\\Avoc@\\"+"rep"+"\\"+nomFichier); destinationFile.createNewFile();

}

/**
* Supprime un document à la GED	
 * @param iddoc
* @param chemin	
*/
public static void deleteDoc(int iddoc,String chemin){

    String sql = "Delete from Fichier where idFichier="+iddoc;
    try {
    Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
    conn.setAutoCommit(true);
    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
    pstmt.executeUpdate();
    conn.commit();
    deleteFichier(chemin);
    System.out.println("Fichier supprimer");
    }
    } catch (SQLException e) {System.err.println(e.getMessage());}
}
/**
* Supprime un Fichier vide dans l'architecture
* @param chemin
*/
public static void deleteFichier(String chemin) {
    new File(chemin).delete();
   }

/**
* Ajoute un utilisateur un droit sur un fichier
* @param nomDoc	
* @param nomUser
* @param chemin	
*/
void shareDoc(String nomDoc, String nomUser, String chemin){}

/**
* Ajoute un utilisateur un droit sur un dossier
* @param nomFolder	
* @param nomUser
* @param chemin
*/
void shareFolder(String nomFolder, String nomUser, String chemin){}

/**
* Supprime le droit d'accès à un fichier, pour un utilisateur
     * @param iddoc
     * @param iduser
*/
public static void deleteAccessDoc(int iddoc,int iduser){
    String sql = "Delete from droitfichier where idFichier="+iddoc+"and iduser="+iduser;
    try {
    Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
    conn.setAutoCommit(true);
    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
    pstmt.executeUpdate();
    conn.commit();
    System.out.println("Droit d'acces Fichier supprimer");
    }
    } catch (SQLException e) {System.err.println(e.getMessage());}
}

/**
* Supprime le droit d'accès à un dossier, pour un utilisateur
* @param idfol
* @param iduser
*/
public static void deleteAccessFolder(int idfol,int iduser){
     String sql = "Delete from droitdossier where iddossier="+idfol+"and iduser="+iduser;
     try {
     Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
     conn.setAutoCommit(true);
     try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
     pstmt.executeUpdate();
     conn.commit();
     System.out.println("Droit d'acces dossier supprimer");
     }
     } catch (SQLException e) {System.err.println(e.getMessage());}
}

/**
* Créer un dossier dans l'architecture GED
* @param id
* @param nomfol
*/
public static void createFolder(int id,String nomfol){
     String sql = "INSERT INTO Dossier VALUES (?,?)";
     try {
     Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
     conn.setAutoCommit(true);
     try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
     pstmt.setInt(1, id);
     pstmt.setInt(2, id);
     pstmt.executeUpdate();
     conn.commit();
     System.out.println("Dossier creer");
     }
     }catch (SQLException e) {System.err.println(e.getMessage());}

}

/**
* Supprime un dossier vide dans l'architecture
* @param idfol
* @param chemin
* @throws java.sql.SQLException
*/
public static void deleteFolder(int idfol,String chemin) throws SQLException{
     deleteDocFolder(idfol);
     deleteFol(idfol);
     deleteDroitFol(idfol);
     deleteDossier(chemin);
     String sql = "Delete from dossier where iddossier="+idfol;
     try {
     Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
     conn.setAutoCommit(true);
     try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
     conn.commit();
     pstmt.executeUpdate();
     conn.commit();
     System.out.println("Dossier supprimer");
     }
     }catch (SQLException e) {System.err.println(e.getMessage());}
    
}
/**
* Supprime un dossier vide dans l'architecture
* @param chemin
*/
   public static void deleteDossier(String chemin) {
      new File(chemin).delete();
      System.out.println("Dossier supprimer");
   }

/**
* Supprime Tous les fichier d'un dossier dans l'architecture fichierdansdossier
* @param iddoc
* @throws java.sql.SQLException
*/
public static void deleteDocFolder(int iddoc) throws SQLException{
        int idfichier=SearchDoc(iddoc);
        String sql = "Delete from fichierdansdossier where idfichier="+idfichier;
        try {
        Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
        conn.setAutoCommit(true);
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.executeUpdate();
        conn.commit();
        System.out.println("Fichier supprimer");
        }
        }catch (SQLException e) {System.err.println(e.getMessage());}
    
}
/**
* Supprime un dossier dans l'architecture dossierdansdossier
* @param idfol
* @throws java.sql.SQLException
*/
public static void deleteFol(int idfol) throws SQLException{
  
        String sql = "Delete from dossierdansdossier where iddossierfils="+idfol;
        try {
        Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
        conn.setAutoCommit(true);
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.executeUpdate();
        conn.commit();
        System.out.println("Dossier fils supprimer");
        }
        } catch (SQLException e) {System.err.println(e.getMessage());}
}
/**
* Supprime un dossier dans l'architecture Droitdossier
* @param idfol
* @throws java.sql.SQLException
*/
public static void deleteDroitFol(int idfol) throws SQLException{
  
        String sql = "Delete from droitdossier where iddossier="+idfol;
        try {
        Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
        conn.setAutoCommit(true);
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.executeUpdate();
        conn.commit();
        System.out.println("Dossier avec droit supprimer");
        }
        } catch (SQLException e) {System.err.println(e.getMessage());}
    
}
/**
* Recherche un fichier  dans l'architecture
* @param idfol
* @return 
* @throws java.sql.SQLException
*/
public static int SearchDoc(int idfol) throws SQLException{
        String sql = "select idfichier from fichierdansdossier where iddossier="+idfol;
        Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
        conn.setAutoCommit(true);
        // Execute the query
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql) ;
        rs.next();
        return rs.getInt(1); 

            
    
}

/**
* Renvoi les information du dossier contenue dans le XML
* @param nomFolder
* @throws java.sql.SQLException
*/
public static void infoFolder(String nomFolder) throws SQLException{

}

/**
* Renvoi l'id du dossier contenu dans le XML
* @param nomDoc
* @return	id du doc passé en paramètre
*/
public static int getIdDoc(String nomDoc){return 0;
}

/**
* 
* @param nomFolder
* @throws java.sql.SQLException
*/
public static void getIdFolder(String nomFolder) throws SQLException{
 
       String sql = "select iddossier from dossier where NOMDOSSIER="+nomFolder;  
       Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@im2ag-oracle.e.ujf-grenoble.fr:1521:im2ag","diallo1", "Sory1993");
       conn.setAutoCommit(true);
    // Execute the query
       Statement stmt = conn.createStatement();
       ResultSet rs = stmt.executeQuery(sql) ;
       rs.next();
       System.out.print(rs.getInt(1)); 

     
}

/**
* 
* @param nomDoc
* @return	type du document passé en paramètre
*/
public static String getTypeDoc(String nomDoc){return null;
}

/**
* 
* @param nomDoc
* @return	chemin du document passé en paramètre
*/
public static String getCheminDoc(String nomDoc){return null;
}

/**
* 
* @param nomFolder
* @return	chemin du dossier passé en paramètre
*/
public static String getCheminFolder(String nomFolder){return null;
}

/**
* 
* @param nomFolder
* @return	???
*/
public static String getAccessFolder(String nomFolder){return null;
}

/**
* 
* @param nomDoc
* @return	???
*/
public static String getAccessDoc(String nomDoc){return null;
}

/**
* 
* @param nomFolder
* @return	???
*/
public static String getRacineFolder(String nomFolder){return null;
}

/**
* 
* @param nomFolder
* @return	???
*/
public static String getFilsFolder(String nomFolder){return null;
}


    
    
}
