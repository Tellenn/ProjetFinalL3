/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package writer;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import static java.util.Collections.list;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


/**
 *
 * @author diallo1
 */
public class RequeteParserDom {
     private final String chemin="document"; 
     public void Requete(){ }
    
     public void readedocument () throws SAXException, IOException, ParserConfigurationException {

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder p = dbFactory.newDocumentBuilder();
           // récupération de la structure objet du document
            Document doc = p.parse(chemin);
            System.out.println("Affichage des élément");
            System.out.println(doc.getElementById("id"));
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(1).getAttributes().item(0));
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(1).getChildNodes().item(1).getNodeName());
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(1).getChildNodes().item(1).getTextContent());
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(1).getChildNodes().item(3).getNodeName());
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(1).getChildNodes().item(3).getTextContent());
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(1).getChildNodes().item(5).getNodeName());
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(1).getChildNodes().item(5).getTextContent());
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(3).getAttributes().item(0));
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(3).getChildNodes().item(1).getNodeName());
            System.out.println(doc.getChildNodes().item(0).getChildNodes().item(3).getChildNodes().item(1).getTextContent());
           
           
     }
     public void delneoud(String id) throws ParserConfigurationException, SAXException, IOException{
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder p = dbFactory.newDocumentBuilder();
            // récupération de la structure objet du document
            Document doc = p.parse(chemin);
            NodeList list= doc.getElementsByTagName("document"); 
            int i=list.getLength();
            Node root = doc.getFirstChild();
            while (i>0){ 
              i--;
              Node child = list.item(i); 
              Element childElt = (Element)child; 
              String atr = childElt.getAttribute("id"); 

              if (atr.equals(id)){ 
                 root.removeChild(child); 
              } 
           } 
      save(doc);
     }
     //modifier un noeud 
     public void updatenoeud(String id,String nom)  throws SQLException, ParserConfigurationException, SAXException, IOException {
    
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder p = dbFactory.newDocumentBuilder();
        // récupération de la structure objet du document
        Document doc = p.parse(chemin); 
	
	        Element racine = doc.getDocumentElement();
                NodeList racineNoeuds = racine.getChildNodes();
	 	int nbRacineNoeuds = racineNoeuds.getLength();
	 	for (int i = 0; i<nbRacineNoeuds; i++) {
                if(racineNoeuds.item(i).getNodeType() == Node.ELEMENT_NODE) {
                Element personne = (Element) racineNoeuds.item(i);
                Node nomNoeud = personne.getChildNodes().item(1);

            //Affichage d'une personne
                String idp = personne.getAttribute("id");
                if (idp.compareTo(id)==0){
                nomNoeud.setTextContent(nom);

		            }
		    	}
		    }

	 	  save(doc);
	 	   
	    }
     
     
    /**
* Supprime un dossier vide dans l'architecture
* @param chemin
* @param nomFolder
*/
public void deleteFichier(String chemin) throws SQLException{
   
    
    
}
     
     //Ajout d'un noeud
     public void adnoued(String des) throws ParserConfigurationException, SAXException, IOException{
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder p = dbFactory.newDocumentBuilder();
             // récupération de la structure objet du document
                Document doc = p.parse(chemin);
               
               // doc.appendChild("document");
                Element document = doc.createElement("document");
                document.setAttribute("id", Integer.toString(doc.getElementsByTagName("document").getLength()+1));
                document.setTextContent(des);
                doc.getFirstChild().appendChild(document);
                save(doc);
     }
     public void adnouedAttribut(String attrib,String valeur,String id) throws ParserConfigurationException, SAXException, IOException{
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder p = dbFactory.newDocumentBuilder();
             // récupération de la structure objet du document
                Document doc = p.parse(chemin);
                NodeList list= doc.getElementsByTagName("document"); 
                int i=list.getLength();
                Node root = doc.getFirstChild();
                while (i>0){ 
                i--;
                Node child = list.item(i); 
                Element childElt = (Element)child; 
                String atr = childElt.getAttribute("id"); 

                if (atr.equals(id)){ 
                Element document = doc.createElement(attrib);
                document.setTextContent(valeur);
                doc.getElementById(atr).appendChild(document);
                save(doc);
                } 
             
              
                }
     }
     
     // enregistrement
     public void save(Document doc ) throws ParserConfigurationException, SAXException, IOException{
                
               
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer;
		try {
	        transformer = transformerFactory.newTransformer();			
	        DOMSource source = new DOMSource(doc);
                StreamResult result = new StreamResult("document");
	        transformer.transform(source, result);
		} catch (TransformerException e) {
                }
     }
}
