/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package writer;

import java.io.IOException;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 *
 * @author diallo1
 */
public class TestParserDom {
    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, SQLException {
  
         RequeteParserDom p=new RequeteParserDom();
        // p.readedocument();
     //    p.adnoued("Carnet");
   // p.delneoud("3");
         
        
         
      //  p.adnouedAttribut("Desc", "Mon dossier prefere", "1");
        // p.updatenoeud("2","Mon fichier bien");
    }
    
}
