package writer;

import java.sql.Connection;
import java.sql.DriverManager;

class Connexionsgbd {
    private static final String configurationFile ="BD.properties";
    public static void main( String args[] ) {
        //Requetesql p=new Requetesql();
          //p.deleteDossier("/home/d/diallo1/NetBeansProjects/Employe");
        try {
        String jdbcDriver, dbUrl, username, password;
        DatabaseAccessProperties dap = new DatabaseAccessProperties(configurationFile);
        jdbcDriver= dap.getJdbcDriver();
        dbUrl = dap.getDatabaseUrl();
        username = dap.getUsername();
        password = dap.getPassword();
        System.out.println(username);
        System.out.println(password);
        // Load the database driver
        Class.forName(jdbcDriver) ;// Get a connection to the database
          
            try (Connection conn = DriverManager.getConnection(dbUrl,username, password)) {
                
               
                //Requetesql.addDoc(1,"Mon doc",1,"Doc","12-NOV-2017");
             // Requetesql.deleteFolder(4,"/home/d/diallo1/NetBeansProjects/Employe");
               // Requetesql.deleteAccessDoc(4, 3);
               // Requetesql.deleteAccessFolder(5, 2);
              //  Requetesql.deleteFolder(5);
               // Requetesql.getIdFolder("RH");
              //  RequetesqlGED.getRacineFolder(2);   
               // RequetesqlGED.getAccessFolder(3);
               // RequetesqlGED.shareFolder(3,1);
               // RequetesqlGED.shareDoc(2,3);
                 //RequetesqlGED.getTypeDoc();
                RequetesqlGED.infoFolder("RH");
                
                SQLWarningsExceptions.printWarnings(conn);
            }
        }
        //catch( SQLException se ) {
        // Print information about SQL exceptions
        //SQLWarningsExceptions.printExceptions(se);
        //return;
        //}
        catch( Exception e ) {
        System.err.println( "Excepssion: " + e.getMessage()) ;
        e.printStackTrace();
        return;
        }
    }
}

