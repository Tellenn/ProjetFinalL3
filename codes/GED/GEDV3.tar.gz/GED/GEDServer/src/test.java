
public class test {
	public static void main(String[] args){
		StartServer.start("152.77.82.35");
	}
}
