
public class test {
	public static void main(String[] args){
		//InteractionClient.downloadFile("152.77.82.35","Kyllian","/home/p/perrink/Bureau/","me.jpg","GED/");
                InteractionClient.DeleteFile("152.77.82.35", 4, "/home/d/diallo1/images.jpeg");
	}
}
